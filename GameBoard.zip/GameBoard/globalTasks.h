#define _TASK_STATUS_REQUEST
#define _TASK_TIMEOUT
#include <TaskSchedulerDeclarations.h>

extern Scheduler ts;
