#include "readCells.h"

// These are the constructors as defined in the HX711_ADC header file
HX711_ADC TopRight(HX711_dout_1, HX711_sck_1); //HX711 1
HX711_ADC BottomRight(HX711_dout_2, HX711_sck_2); //HX711 2
HX711_ADC TopLeft(HX711_dout_3, HX711_sck_3); //HX711 3
HX711_ADC BottomLeft(HX711_dout_4, HX711_sck_4); //HX711 4

unsigned long t = 0;

void setupCells() {
  
  // Break-line sensor
  //attachInterrupt(digitalPinToInterrupt(2), increment, RISING);
  
  float calibrationValue_1; // calibration value load cell 1
  float calibrationValue_2; // calibration value load cell 2
  float calibrationValue_3; // calibration value load cell 3
  float calibrationValue_4; // calibration value load cell 4

  calibrationValue_1 = -300;
  calibrationValue_2 = 404.17; 
  calibrationValue_3 = -261.92; 
  calibrationValue_4 = 271.21; 
  
  // Begin is what powers up the HX711, sets the pinMode and HX711 gain
  TopRight.begin();
  BottomRight.begin();
  TopLeft.begin();
  BottomLeft.begin();
  
   // Waiting for tare to stabilize
  unsigned long stabilizingtime = 2000;
  
  
  boolean _tare = true; //set this to false if you don't want tare to be performed in the next step
  byte TopRight_rdy = 0;
  byte BottomRight_rdy = 0;
  byte TopLeft_rdy = 0;
  byte BottomLeft_rdy = 0;
  
  while ((TopRight_rdy + BottomRight_rdy + TopLeft_rdy + BottomLeft_rdy) < 4) { //run startup, stabilization and tare, both modules simultaniously
    if (!TopRight_rdy) TopRight_rdy = TopRight.startMultiple(stabilizingtime, _tare);
    if (!BottomRight_rdy) BottomRight_rdy = BottomRight.startMultiple(stabilizingtime, _tare);
    if (!TopLeft_rdy) TopLeft_rdy = TopLeft.startMultiple(stabilizingtime, _tare);
    if (!BottomLeft_rdy) BottomLeft_rdy = BottomLeft.startMultiple(stabilizingtime, _tare);
  }
  if (TopRight.getTareTimeoutFlag()) {
    Serial.println("Timeout, check MCU>HX711 no.1 wiring and pin designations");
  }
  if (BottomRight.getTareTimeoutFlag()) {
    Serial.println("Timeout, check MCU>HX711 no.2 wiring and pin designations");
  }
  
   // user set calibration values
  TopRight.setCalFactor(calibrationValue_1);
  BottomRight.setCalFactor(calibrationValue_2);
  TopLeft.setCalFactor(calibrationValue_3);
  BottomLeft.setCalFactor(calibrationValue_4);
  Serial.println("Startup is complete");
}